<?php
$dil = array(
    "homepage"		=> "Ana sayfa",
	"azdil"			=> "Azerbaycan dili",
	"ingdil"		=> "İngiliz dili",
	"rusdil"		=> "Rus dili",
	"trdil"			=> "Türk dili",
	"search"		=> "Arama",
	"contact"		=> "Bağlantı",
	"logout"		=> "Çıkış",
	"profile"		=> "Profil"
	 

);
?>