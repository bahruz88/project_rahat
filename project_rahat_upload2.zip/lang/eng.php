<?php
$dil = array(
    "homepage"		=> "Home Page",
	"azdil"			=> "Azerbaijan",
	"engdil"		=> "English",
	"rusdil"		=> "Russian",
	"trdil"			=> "Turkish",
	"search"		=> "Search",
	"contact"		=> "Contact",
	"logout"		=> "Log Out",
	"profile"		=> "Profile" ,
	"adminpage"		=> "Administration",
	"users"			=> "Users"	,
	"dashboard"	    => "Dashboard",
	"addnew"	    => "Add New Item",
	"datanotfound"	=> "Data Not found",
    "previous"	=> "Previous",
	"next"	=> "Next" ,
	"display"=> "Display"
);
?>