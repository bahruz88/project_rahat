<?php
include('../session.php');
$site_lang=$_SESSION['dil'] ;
include('st_selectWithComp2.php');


?>