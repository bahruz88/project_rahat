<?php
include('../session.php');
$site_lang=$_SESSION['dil'] ;
include('st_selectWithCompPage.php');


?>